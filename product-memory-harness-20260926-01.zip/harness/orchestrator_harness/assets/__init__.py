"""Packaged harness assets."""
