# Local run configuration

This directory is intentionally ignored by Git. No credential value is stored
here. `activate-run.ps1` reads the host-only files under `.secrets/creds` into
the current PowerShell process and prints only non-secret readiness facts.

From the run workspace root:

```powershell
. .\harness\local-config\activate-run.ps1
```

For the benchmark preflight, use `-RetainAtlasHandoff`: the UUID-scoped Atlas
collection and its handoff manifest are the durable registration for the exact
run ID. Credentials remain host-only and are never copied into a lane.
