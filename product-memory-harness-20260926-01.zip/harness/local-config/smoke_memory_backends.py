"""Credential-backed, run-scoped EverOS and Atlas preflight.

The script stores no credentials.  ``activate-run.ps1`` supplies host-only
environment variables.  A successful Atlas document and index are retained as
the benchmark run registration; an incomplete Atlas attempt is dropped.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

from langchain_core.embeddings import Embeddings
from langchain_mongodb import MongoDBAtlasVectorSearch
from memory_harness.experience import (
    EverOSAdapter,
    ExperienceScope,
    load_vendored_everos_public_surface,
)
from pymongo import MongoClient


def required(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"required environment variable is absent: {name}")
    return value


def as_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    dump = getattr(value, "model_dump", None)
    if callable(dump):
        result = dump(mode="json")
        if isinstance(result, dict):
            return result
    raise RuntimeError(f"EverOS returned an unsupported value: {type(value).__name__}")


async def exercise_everos(text: str) -> tuple[list[float], list[float], str]:
    from everos.component.embedding import get_embedding_capability
    from everos.config import load_settings
    from everos.infra.persistence.lancedb import (
        AgentCase,
        agent_case_repo,
        ensure_business_indexes,
        lancedb_manager,
    )

    import everos.component.embedding.accessor as embedding_accessor
    import everos.service.search as search_service

    scope = ExperienceScope(
        application=required("MEMORY_HARNESS_EVEROS_APPLICATION"),
        project=required("MEMORY_HARNESS_EVEROS_PROJECT"),
        namespace=required("MEMORY_HARNESS_EVEROS_NAMESPACE"),
        owner=required("MEMORY_HARNESS_EVEROS_OWNER"),
    )
    memory_root = Path(required("EVEROS_ROOT")).resolve()
    memory_root.mkdir(parents=True, exist_ok=True)
    expected = EverOSAdapter.memory_root_for_scope(memory_root.parent, scope)
    if memory_root != expected:
        raise RuntimeError("EVEROS_ROOT does not match the benchmark scope")

    load_settings.cache_clear()
    embedding_accessor._capability = None
    search_service._manager = None
    lancedb_manager._conn = None
    lancedb_manager._tables.clear()

    surface = load_vendored_everos_public_surface(memory_root=memory_root)
    adapter = EverOSAdapter(scope=scope, base_root=memory_root.parent, surface=surface)
    capability = get_embedding_capability()
    if not capability.available:
        raise RuntimeError(f"EverOS embedding capability unavailable: {capability.reason}")
    provider = capability.require()
    approach = "Use the native product harness with a late independent validator."
    document_vector = await provider.embed(text + "\n" + approach)
    query_vector = await provider.embed(text)
    if not document_vector or len(document_vector) != len(query_vector):
        raise RuntimeError("EverOS embedder returned inconsistent vectors")

    run_id = required("MEMORY_HARNESS_RUN_ID")
    run_token = required("MEMORY_HARNESS_ATLAS_RUN_TOKEN")
    entry_id = "run-registration-" + run_token
    case_id = adapter.everos_owner_id + "_" + entry_id
    session_id = "benchmark-" + run_token
    case = AgentCase(
        id=case_id,
        entry_id=entry_id,
        owner_id=adapter.everos_owner_id,
        owner_type="agent",
        app_id=adapter.everos_application_id,
        project_id=adapter.everos_project_id,
        session_id=session_id,
        timestamp=dt.datetime.now(dt.UTC),
        parent_type="memcell",
        parent_id=run_id,
        quality_score=1.0,
        task_intent=text,
        task_intent_tokens=text,
        approach=approach,
        approach_tokens="native product harness late independent validator",
        key_insight="This record identifies the exact preflighted ZSTD run.",
        md_path=f"benchmark-runs/{run_id}.md",
        content_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        vector=document_vector,
    )
    await agent_case_repo.upsert([case])
    await ensure_business_indexes()

    request = surface.make_search_request(
        agent_id=adapter.everos_owner_id,
        app_id=adapter.everos_application_id,
        project_id=adapter.everos_project_id,
        query=text,
        method="vector",
        top_k=5,
    )
    response = as_mapping(await surface.search(request))
    data = response.get("data")
    if not isinstance(data, dict):
        raise RuntimeError("EverOS vector recall returned no data object")
    cases = data.get("agent_cases")
    if not isinstance(cases, list) or not any(
        as_mapping(item).get("id") == case_id for item in cases
    ):
        raise RuntimeError("EverOS vector recall did not return the registered run")
    return document_vector, query_vector, case_id


class CapturedEmbeddings(Embeddings):
    def __init__(self, document_vector: list[float], query_vector: list[float]) -> None:
        self.document_vector = document_vector
        self.query_vector = query_vector

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [list(self.document_vector) for _ in texts]

    def embed_query(self, text: str) -> list[float]:
        return list(self.query_vector)


def exercise_atlas(
    text: str,
    document_vector: list[float],
    query_vector: list[float],
    everos_case_id: str,
) -> dict[str, Any]:
    run_id = required("MEMORY_HARNESS_RUN_ID")
    token = required("MEMORY_HARNESS_ATLAS_RUN_TOKEN")
    database_name = required("MEMORY_HARNESS_ATLAS_LIVE_DATABASE")
    collection_name = "trusted_procedures_" + token
    index_name = "vector_" + token
    client = MongoClient(required("MEMORY_HARNESS_ATLAS_URI"), serverSelectionTimeoutMS=10_000)
    collection = client[database_name][collection_name]
    if collection.estimated_document_count() != 0:
        raise RuntimeError("owned Atlas registration collection is not empty")
    vector_store = MongoDBAtlasVectorSearch(
        collection=collection,
        embedding=CapturedEmbeddings(document_vector, query_vector),
        index_name=index_name,
        text_key="search_text",
        embedding_key="procedure_embedding",
        relevance_score_fn="cosine",
    )
    try:
        vector_store.create_vector_search_index(
            dimensions=len(document_vector),
            filters=["run_id", "document_kind"],
            wait_until_complete=120.0,
        )
        ids = vector_store.add_texts(
            [text],
            metadatas=[
                {
                    "run_id": run_id,
                    "run_token": token,
                    "document_kind": "benchmark_run_registration",
                    "everos_case_id": everos_case_id,
                    "embedding_model": required("EVEROS_EMBEDDING__MODEL"),
                    "registered_at": dt.datetime.now(dt.UTC).isoformat(),
                }
            ],
            ids=["run-registration-" + token],
        )
        deadline = time.monotonic() + 90.0
        hits: list[tuple[Any, float]] = []
        while time.monotonic() < deadline:
            hits = vector_store.similarity_search_with_score(
                text + " recall",
                k=1,
                pre_filter={"run_id": {"$eq": run_id}},
            )
            if hits and hits[0][0].metadata.get("run_id") == run_id:
                break
            time.sleep(1.0)
        if not hits or hits[0][0].metadata.get("run_id") != run_id:
            raise RuntimeError("Atlas vector recall did not return the registered run")
        result = {
            "schema": "benchmark-memory-registration/v1",
            "run_id": run_id,
            "atlas_run_token": token,
            "atlas_database": database_name,
            "atlas_collection": collection_name,
            "atlas_index": index_name,
            "atlas_document_id": ids[0],
            "atlas_recall_score": float(hits[0][1]),
            "everos_case_id": everos_case_id,
            "everos_root": required("EVEROS_ROOT"),
            "embedding_model": required("EVEROS_EMBEDDING__MODEL"),
            "embedding_dimensions": len(document_vector),
            "registered_at": dt.datetime.now(dt.UTC).isoformat(),
        }
        manifest_path = Path(required("MEMORY_HARNESS_ATLAS_HANDOFF_MANIFEST_PATH"))
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = manifest_path.with_suffix(manifest_path.suffix + ".tmp")
        temporary.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        temporary.replace(manifest_path)
        return result
    except BaseException:
        collection.drop()
        raise
    finally:
        client.close()


def main() -> None:
    text = (
        "Register the ZSTD decoder product-harness benchmark run with "
        "Terra high Priority workers and late validation."
    )
    document_vector, query_vector, case_id = asyncio.run(exercise_everos(text))
    result = exercise_atlas(text, document_vector, query_vector, case_id)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
